//
//  main.m
//  WeatherApp
//
//  Created by Simon Strobel on 14.03.15.
//  Copyright (c) 2015 Simon Strobel. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
