//
//  TopTabBar.swift
//  PickNPayDemoShoppingApplicationIoS
//
//  Created by Reverside Software Solutions on 2/23/18.
//  Copyright © 2018 Reverside Software Solutions. All rights reserved.
//

import UIKit

class TopTabBar: UITabBarController{
    
    @IBOutlet weak var labelItemCustomer: UIBarButtonItem!
    
    @IBAction func logoutButtonPressed(_ sender: Any) {
        
        self.performSegue(withIdentifier: "logOutButtonPressed", sender: self)
    }
    
}
