//
//  User.swift
//  PickNPayDemoShoppingApplicationIoS
//
//  Created by Reverside Software Solutions on 2/26/18.
//  Copyright © 2018 Reverside Software Solutions. All rights reserved.
//

import Foundation
import CoreLocation

class User {
    var email:String
    init(email:String) {
        self.email = email
    }
}

